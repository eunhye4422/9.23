import React from 'react';
import ReactDOM from 'react-dom';

//import App from './App';
import Web from './Web';

ReactDOM.render(<Web />,document.getElementById('root'));

// map,filter

/*var nArr = [];

for ( var i = 0; i < a.length; i++ ) {
    
    nArr.push(a[i] * 2);
}

console.log(nArr);
console.log(a);*/

/*var nArr = a.map(function(v,i){
    
    return v * 2;
});*/

//const nArr = a.map((v,i)=>v * 2);

//var a = [ 10, 20, 30, 40 ];
//
//const nArr = a.filter((v,i)=>v>20);

/*var nArr = a.filter(function(v,i){
    
    return v > 20;
});*/

//console.log(nArr);
//console.log(a);















