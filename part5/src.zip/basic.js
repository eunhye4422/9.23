import React, { Component } from 'react';

class Web extends Component {
    
    render(){
        return (
            <h1>데이터를 다루어 보자</h1>
        )
    }
}

export default Web;